// Default set of functions for Web Workers
